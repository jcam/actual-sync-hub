declare class Query {
    /** @type {import('@actual-app/core/shared/query').QueryState} */
    state: import('@actual-app/core/shared/query').QueryState;
    constructor(state: any);
    filter(expr: any): Query;
    unfilter(exprs: any): Query;
    select(exprs?: any[]): Query;
    calculate(expr: any): Query;
    groupBy(exprs: any): Query;
    orderBy(exprs: any): Query;
    limit(num: any): Query;
    offset(num: any): Query;
    raw(): Query;
    withDead(): Query;
    withoutValidatedRefs(): Query;
    options(opts: any): Query;
    serialize(): import("@actual-app/core/shared/query").QueryState;
    reset(): Query;
    serializeAsString(): string;
}
export declare function q(table: any): Query;
export {};
//# sourceMappingURL=query.d.ts.map