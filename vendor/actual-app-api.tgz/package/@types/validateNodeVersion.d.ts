export declare function validateNodeVersion(): void;
//# sourceMappingURL=validateNodeVersion.d.ts.map