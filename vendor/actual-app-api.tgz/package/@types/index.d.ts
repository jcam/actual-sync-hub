import type { InitConfig, lib } from '@actual-app/core/server/main';
export * from './methods';
export * as utils from './utils';
/** @deprecated Please use return value of `init` instead */
export declare let internal: typeof lib | null;
export declare function init(config?: InitConfig): Promise<{
    getDataDir: () => string;
    sendMessage: (msg: any, args: any) => void;
    send: <K extends keyof import("@actual-app/core/types/handlers").Handlers, T extends import("@actual-app/core/types/handlers").Handlers[K]>(name: K, args?: Parameters<T>[0]) => Promise<Awaited<ReturnType<T>>>;
    on: (name: any, func: any) => void;
    q: typeof import("@actual-app/core/shared/query").q;
    db: typeof import("@actual-app/core/server/db/index");
    amountToInteger: typeof import("@actual-app/core/shared/util").amountToInteger;
    integerToAmount: typeof import("@actual-app/core/shared/util").integerToAmount;
}>;
export declare function shutdown(): Promise<void>;
//# sourceMappingURL=index.d.ts.map