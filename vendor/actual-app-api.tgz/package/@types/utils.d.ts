export declare const amountToInteger: typeof import("@actual-app/core/shared/util").amountToInteger;
export declare const integerToAmount: typeof import("@actual-app/core/shared/util").integerToAmount;
//# sourceMappingURL=utils.d.ts.map